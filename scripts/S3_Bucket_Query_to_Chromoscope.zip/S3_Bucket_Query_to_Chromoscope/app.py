from flask import Flask, render_template, request, jsonify
import pandas as pd
import time
import boto3
from botocore import UNSIGNED
from botocore.client import Config
from tools import get_matching_s3_objects, generate_presigned_URL, UrlsafeCodec, create_json_config

app = Flask(__name__)

bucket_name = 'cmgginternshipbucket'
dropdown_options = {
    'assembly': ['hg38', 'hg19'],
    'cancer': ['disease1', 'disease2']
}


@app.route('/')
def index():
    return render_template('index.html', dropdown_options=dropdown_options)


@app.route('/search', methods=['POST'])
def search():
    search_query = request.form.get('PROBAND', '')
    path = tuple(request.form.get('PATH', '').split(',')) if ',' in request.form.get('PATH', '') else request.form.get('PATH', '')
    suffix = tuple(request.form.get('SUFFIX', '').split(',')) if ',' in request.form.get('SUFFIX', '') else request.form.get('SUFFIX', '')
    error = data = timing = entries = None

    try:
        start = time.time()
        response = {'Contents': list(get_matching_s3_objects(bucket=bucket_name, path=path, suffix=suffix, search_query=search_query))}
        df = pd.DataFrame(response['Contents'])
        entries = df.shape[0]
        timing = round(time.time() - start, 3)

        df['Presigned URL'] = df.apply(lambda row: generate_presigned_URL(bucket_name, row['Key']), axis=1)
        df['Select'] = '<input type="checkbox" class="result-checkbox" data-key="' + df['Presigned URL'] + '">'
        df['Presigned URL'] = df['Presigned URL'].apply(lambda x: f'<a href="{x}" target="_blank">link</a>')
        df['Filetype'] = df['Key'].apply(lambda x: x.split('.')[-1])
        df['Filename'] = df['Key'].apply(lambda x: x.split('/')[-1].split('.')[0])

        data = df[['Select', 'Filename', 'Filetype']].to_html(index=False, render_links=True, escape=False)
    except ValueError:
        error = 'Invalid text input. Please enter valid text.'
    except Exception as e:
        error = f"An error occurred: {str(e)}"

    return jsonify({'data': data, 'error': error, 'timing': timing, 'entries': entries})


@app.route('/generate_config', methods=['POST'])
def generate_config():
    data = request.json
    json_config = create_json_config(data)
    return jsonify({'config': json_config})


@app.route('/visualize_chromoscope', methods=['POST'])
def visualize_chromoscope():
    data = request.json
    json_config = create_json_config(data)
    encoded_config = UrlsafeCodec.encode(json_config)
    return jsonify({'chromoscope_url': f"http://localhost:3000/app/?showSamples=true&external={encoded_config}"})


if __name__ == '__main__':
    app.run(debug=True)
